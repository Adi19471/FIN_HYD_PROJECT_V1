-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: finance_db
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accountmaster`
--

DROP TABLE IF EXISTS `accountmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accountmaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `visibility` bit(1) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `master_code` varchar(255) DEFAULT NULL,
  `master_icon` varchar(255) DEFAULT NULL,
  `person_type` varchar(255) DEFAULT NULL,
  `trans_type` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `modified_date` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_am_mastercode_code` (`master_code`,`code`),
  KEY `idx_am_visibility` (`visibility`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountmaster`
--

LOCK TABLES `accountmaster` WRITE;
/*!40000 ALTER TABLE `accountmaster` DISABLE KEYS */;
INSERT INTO `accountmaster` VALUES (1,_binary '','ANNIVARSARY EXPENCES','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(2,_binary '','BANK CHARGES','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(3,_binary '','BONUS','SALARIES','/images/salary.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(4,_binary '','CABLE TV BILL','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(5,_binary '','CAPITAL','CAPITAL','/images/capital.png','Partner','Debit,Credit','LIABILITIES',NULL,NULL,NULL,NULL),(6,_binary '','CAPITAL EXCESS','CAPITAL','/images/capital.png','Partner','Debit,Credit','LIABILITIES',NULL,NULL,NULL,NULL),(7,_binary '','CAPITAL LATE INT','CAPITAL','/images/capital.png','Partner','Credit','REVENUES',NULL,NULL,NULL,NULL),(8,_binary '','CHITS INSTALLMENTS','CHITS','/images/advance.png','Employee,Vendor,Customer,Partner','Debit,Credit','ASSETS',NULL,NULL,NULL,NULL),(9,_binary '','COMPANY SAVINGS','SAVINGS','/images/savings.png','Employee,Vendor,Customer,Partner','Debit,Credit','LIABILITIES',NULL,NULL,NULL,NULL),(10,_binary '','CUSTOMER SAVINGS','SAVINGS','/images/savings.png','Employee,Vendor,Customer,Partner','Debit,Credit','LIABILITIES',NULL,NULL,NULL,NULL),(11,_binary '','DONATION','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(12,_binary '','ELECTRICITY BILL','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(13,_binary '','EMPLOYEES','SALARIES','/images/salary.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(14,_binary '','EXTRA INCOME','EXTRA INCOME','/images/income.png','Employee,Vendor,Customer,Partner','Credit','REVENUES',NULL,NULL,NULL,NULL),(15,_binary '','FUEL','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(16,_binary '','HAND LOAN','HAND LOAN','/images/savings.png','Employee,Vendor,Customer,Partner','Debit,Credit','LIABILITIES',NULL,NULL,NULL,NULL),(17,_binary '','HDFC','BANK ACCOUNTS','/images/advance.png','Employee,Vendor,Customer,Partner','Debit,Credit','ASSETS',NULL,NULL,NULL,NULL),(18,_binary '','INTEREST PAID','INTEREST','/images/payments.png','Employee,Vendor,Customer,Partner','Debit,Credit','EXPENSES',NULL,NULL,'admin','2026-07-22 21:04:48.447352'),(19,_binary '','INTREST','C.D.INTREST','/images/savings.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(20,_binary '','MD MEETING FEE','MEETING FEE','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(21,_binary '','MD SALARY','SALARIES','/images/salary.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(22,_binary '','MEETING FEE','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(23,_binary '','NEWS PAPER BILL','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(24,_binary '','OFFICE MAINTAINANCE','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(25,_binary '','OFFICE RENT','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(26,_binary '','OTHERS','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(27,_binary '','PARTNER','SHERE AMOUNT','/images/furniture.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(28,_binary '','PARTNER MEETING FEE','MEETING FEE','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(29,_binary '','PARTNERS','SALARIES','/images/salary.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(30,_binary '','PARTNERS DIVIDENDS','DIVIDENDS','/images/savings.png','Employee,Vendor,Customer,Partner','Debit,Credit','EXPENSES',NULL,NULL,NULL,NULL),(31,_binary '','POOJA','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(32,_binary '','PRINTING & STATIONERY','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(33,_binary '','PROFESSIONAL CHARGES','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(34,_binary '','RENT ADVANCE','ADVANCES','/images/advance.png','Employee,Vendor,Customer,Partner','Debit,Credit','ASSETS',NULL,NULL,NULL,NULL),(35,_binary '','SALARY','SALARIES','/images/salary.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(36,_binary '','SALARY ADVANCE','ADVANCES','/images/advance.png','Employee,Vendor,Customer,Partner','Debit,Credit','ASSETS',NULL,NULL,NULL,NULL),(37,_binary '','SHERE','SHERE AMOUNT','/images/furniture.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(38,_binary '','STAMPS','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(39,_binary '','TEA','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(40,_binary '','TELEPHONE BILL','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(41,_binary '','TOUR EXPENDITURE','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(42,_binary '','VEHICLE','ASSETS','/images/loans.png','Employee,Vendor,Customer,Partner','Debit,Credit','ASSETS',NULL,NULL,NULL,NULL),(43,_binary '','VEHICLE MAINTAINANCE','VEHICLE MAINTAINANCE','/images/savings.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(44,_binary '','WATER BILLS','OFFICE EXPENSES','/images/expenses-3.png','Employee,Vendor,Customer,Partner','Debit','EXPENSES',NULL,NULL,NULL,NULL),(45,_binary '\0','DF DOC CHARGES','DOCUMENT CHARGES',NULL,NULL,NULL,'REVENUES',NULL,NULL,NULL,NULL),(46,_binary '\0','DF INTEREST','INTEREST',NULL,NULL,NULL,'REVENUES',NULL,NULL,NULL,NULL),(47,_binary '\0','DF LATE FEE','LATE FEE',NULL,NULL,NULL,'REVENUES',NULL,NULL,NULL,NULL),(48,_binary '\0','DF LOAN','LOANS',NULL,NULL,NULL,'ASSETS',NULL,NULL,NULL,NULL),(49,_binary '\0','MF DOC CHARGES','DOCUMENT CHARGES',NULL,NULL,NULL,'REVENUES',NULL,NULL,NULL,NULL),(50,_binary '\0','MF INTEREST','INTEREST',NULL,NULL,NULL,'REVENUES',NULL,NULL,NULL,NULL),(51,_binary '\0','MF LATE FEE','LATE FEE',NULL,NULL,NULL,'REVENUES',NULL,NULL,NULL,NULL),(52,_binary '\0','MF LOAN','LOANS',NULL,NULL,NULL,'ASSETS',NULL,NULL,NULL,NULL),(53,_binary '\0','DF LOAN INSTALLMENT','DF LOAN INSTALLMENT',NULL,'','','LOANS',NULL,NULL,'admin','2026-05-25 20:19:36.475682'),(54,_binary '\0','MF LOAN INSTALLMENT','MF LOAN INSTALLMENT',NULL,'','','LOANS',NULL,NULL,'admin','2026-05-25 20:19:54.133544'),(55,_binary '','CASH DIPISIT','FD DIPOSIT','','Partner','CREDIT','LIABILITIES','admin','2026-05-18 19:57:38.909215','admin','2026-05-18 20:04:39.973669');
/*!40000 ALTER TABLE `accountmaster` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-24 19:00:25
