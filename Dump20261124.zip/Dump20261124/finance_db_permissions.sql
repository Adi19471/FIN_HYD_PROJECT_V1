-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: finance_db
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `menu` varchar(255) DEFAULT NULL,
  `permission_code` varchar(255) DEFAULT NULL,
  `screen_name` varchar(255) DEFAULT NULL,
  `sub_menu` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK3t7dqv661lw96xkq9kqgmbtw6` (`permission_code`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'Dashboard','DASHBOARD_VIEW','Dashboard',NULL),(2,'Master Info','CUSTOMER_VIEW','Customer','Personal Info'),(3,'Master Info','EMPLOYEE_VIEW','Employee','Personal Info'),(4,'Master Info','PARTNER_VIEW','Partner','Personal Info'),(5,'Master Info','VENDOR_VIEW','Vendor','Personal Info'),(6,'Master Info','LOAN_MAIN_VIEW','Loan Main Page','Loans'),(7,'Master Info','MONTHLY_FINANCE_VIEW','Monthly Finance','Loans'),(8,'Master Info','DAILY_FINANCE_VIEW','Daily Finance','Loans'),(9,'Transactions','BUSINESS_CASHBOOK_VIEW','Business Cash Book','Cash Book'),(10,'Transactions','QUICK_CASHBOOK_VIEW','Quick Cash Book','Cash Book'),(11,'Transactions','DELETE_TRANSACTION_VIEW','Delete Transaction','Cash Book'),(12,'Transactions','CASHBOOK_VIEW','Cashbook','Cash Book'),(13,'Accounts','ACCOUNTS_LOANS_VIEW','Loans Main Page','Ledgers'),(14,'Accounts','ACCOUNT_LEDGER_VIEW','Account Ledger','Ledgers'),(15,'Accounts','ACCOUNT_MASTER_LEDGER_VIEW','Account Master Ledger','Ledgers'),(16,'Accounts','CB_LEDGER_VIEW','CB Ledger','Ledgers'),(17,'Accounts','RECEIPT_LEDGER_VIEW','Receipt Ledger','Ledgers'),(18,'Accounts','DAILY_BOOK_VIEW','Daily Book','Ledgers'),(19,'Accounts','LOAN_DETAILS_VIEW','Loans Details','Ledgers'),(20,'Accounts','USER_COLLECTION_LEDGER_VIEW','User Collection Ledger','Ledgers'),(21,'Loans','DISTRIBUTED_VIEW','Distributed','Reports'),(22,'Loans','INSTALMENT_DUES_VIEW','Instalment Dues','Reports'),(23,'Loans','MATURITY_VIEW','Maturity','Reports'),(24,'Account Master Setup','ACCOUNT_MASTER_SETUP_VIEW','Account Master Setup',NULL),(25,'Account Master Setup','REGISTRATION_CREATION_VIEW','Registration Creation',NULL),(26,'Business','REVENUE_EXPENSE_VIEW','Revenue Expense Statement','Reports'),(27,'Business','BALANCE_SHEET_VIEW','Balance Sheet','Reports'),(28,'Business','BUSINESS_OVERVIEW_VIEW','Business Overview','Reports'),(29,'Business','BUSINESS_COLLECTION_REPORTS_VIEW','Business Collection Reports','Reports'),(30,'Customer Reports','CUSTOMER_DUES_VIEW','Customer Dues',NULL),(31,'Customer Reports','CUSTOMER_OUTSTANDING_VIEW','Customer Outstanding',NULL),(32,'Customer Reports','CUSTOMER_REPORT_VIEW','Customer Report',NULL),(33,'Customer Reports','CUSTOMER_TRANSACTIONS_VIEW','Customer Transactions',NULL),(34,'Partner Reports','PARTNER_BUSINESS_REPORTS_VIEW','Business Reports',NULL),(35,'Partner Reports','GROUP_BUSINESS_DETAILS_VIEW','Group Business Details',NULL),(36,'Partner Reports','GROUP_BUSINESS_VIEW','Group Business',NULL),(37,'Partner Reports','PARTNER_INSTALLMENT_DUES_VIEW','Installment Dues',NULL),(38,'Partner Reports','PARTNER_INFORMATION_VIEW','Partner Information',NULL),(39,'Partner Reports','PARTNER_LOAN_LIMIT_VIEW','Partner Loan Limit',NULL),(40,'Partner Reports','PARTNER_SETTLEMENT_VIEW','Partner Settlement',NULL),(41,'Partner Reports','PERFORMANCE_VIEW','Performance',NULL),(42,'Account Master Setup','BRANCH_MASTER_VIEW','Branch Master',NULL);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-24 19:00:25
